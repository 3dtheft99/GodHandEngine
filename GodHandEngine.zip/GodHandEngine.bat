@echo off
:: Start the monitor in the background (it will remain running)
start "" "GodHandEngine.exe"

:: Wait 1 second for the monitor to stabilize
timeout /t 1 /nobreak >nul

:: Start the modified game without locking the script (removed /wait)
start "" "obse_loader.exe"

:: Exit the CMD window immediately while leaving both processes active
exit